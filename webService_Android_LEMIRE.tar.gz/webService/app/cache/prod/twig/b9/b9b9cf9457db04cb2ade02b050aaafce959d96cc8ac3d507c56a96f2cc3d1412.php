<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_1b43263d4667495c3d9f67c0934bcb9c77b9ba33f5763cfefaae9de1b56093ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_03fe5d5b1fe94a30bc5601c33ecfb062c1d959adf9c9f3ab91e0a902a26e18dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_03fe5d5b1fe94a30bc5601c33ecfb062c1d959adf9c9f3ab91e0a902a26e18dd->enter($__internal_03fe5d5b1fe94a30bc5601c33ecfb062c1d959adf9c9f3ab91e0a902a26e18dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_03fe5d5b1fe94a30bc5601c33ecfb062c1d959adf9c9f3ab91e0a902a26e18dd->leave($__internal_03fe5d5b1fe94a30bc5601c33ecfb062c1d959adf9c9f3ab91e0a902a26e18dd_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
";
    }
}

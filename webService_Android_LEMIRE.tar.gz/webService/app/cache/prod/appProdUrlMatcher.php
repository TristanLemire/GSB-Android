<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // tlweb_service_homepage
        if (0 === strpos($pathinfo, '/hello') && preg_match('#^/hello/(?P<name>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'tlweb_service_homepage')), array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::indexAction',));
        }

        // tlweb_service_getVisiteur
        if ($pathinfo === '/visiteurs') {
            if ($this->context->getMethod() != 'PUT') {
                $allow[] = 'PUT';
                goto not_tlweb_service_getVisiteur;
            }

            return array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::getVisiteurAction',  '_format' => 'json',  '_route' => 'tlweb_service_getVisiteur',);
        }
        not_tlweb_service_getVisiteur:

        // tlweb_Service_getLesRapports
        if (0 === strpos($pathinfo, '/rapports') && preg_match('#^/rapports/(?P<matricule>[^/]++)/(?P<moisSelected>[^/\\.]++)\\.(?P<anneeSelected>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_tlweb_Service_getLesRapports;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'tlweb_Service_getLesRapports')), array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::getListeRapportsAction',  '_format' => 'json',));
        }
        not_tlweb_Service_getLesRapports:

        // tlweb_service_getLesPraticiens
        if ($pathinfo === '/praticiens') {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_tlweb_service_getLesPraticiens;
            }

            return array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::getLesPraticiensAction',  '_format' => 'json',  '_route' => 'tlweb_service_getLesPraticiens',);
        }
        not_tlweb_service_getLesPraticiens:

        // tlweb_service_getLesMotifs
        if ($pathinfo === '/motifs') {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_tlweb_service_getLesMotifs;
            }

            return array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::getLesMotifsAction',  '_format' => 'json',  '_route' => 'tlweb_service_getLesMotifs',);
        }
        not_tlweb_service_getLesMotifs:

        // tlweb_service_getLesCoefs
        if ($pathinfo === '/coefficients') {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_tlweb_service_getLesCoefs;
            }

            return array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::getLesCoefsAction',  '_format' => 'json',  '_route' => 'tlweb_service_getLesCoefs',);
        }
        not_tlweb_service_getLesCoefs:

        // tlweb_service_getLesMedocs
        if ($pathinfo === '/medicaments') {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_tlweb_service_getLesMedocs;
            }

            return array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::getLesMedocsAction',  '_format' => 'json',  '_route' => 'tlweb_service_getLesMedocs',);
        }
        not_tlweb_service_getLesMedocs:

        // tlweb_service_getLesOffresRapport
        if (0 === strpos($pathinfo, '/offrir') && preg_match('#^/offrir/(?P<numRapport>[^/]++)$#s', $pathinfo, $matches)) {
            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'HEAD'));
                goto not_tlweb_service_getLesOffresRapport;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'tlweb_service_getLesOffresRapport')), array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::getLesOffresRapportAction',  '_format' => 'json',));
        }
        not_tlweb_service_getLesOffresRapport:

        // tlweb_service_newRapport
        if ($pathinfo === '/rapports') {
            if ($this->context->getMethod() != 'POST') {
                $allow[] = 'POST';
                goto not_tlweb_service_newRapport;
            }

            return array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::newRapportAction',  '_format' => 'json',  '_route' => 'tlweb_service_newRapport',);
        }
        not_tlweb_service_newRapport:

        // tlweb_service_insertNouvelleOffre
        if ($pathinfo === '/offrir') {
            if ($this->context->getMethod() != 'POST') {
                $allow[] = 'POST';
                goto not_tlweb_service_insertNouvelleOffre;
            }

            return array (  '_controller' => 'tl\\webServiceBundle\\Controller\\DefaultController::insertNouvelleOffreAction',  '_format' => 'json',  '_route' => 'tlweb_service_insertNouvelleOffre',);
        }
        not_tlweb_service_insertNouvelleOffre:

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
